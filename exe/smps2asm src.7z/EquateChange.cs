﻿namespace smps2asm {
	internal class EquateChange {
		public string name { get; }
		public string value { get; }

		public EquateChange(string name, string value) {
			this.name = name;
			this.value = value;
		}
	}
}