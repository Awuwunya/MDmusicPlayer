﻿namespace smps2asm {
	internal class Command {
		public string command { get; }

		public Command(string comm) {
			command = comm;
		}
	}
}