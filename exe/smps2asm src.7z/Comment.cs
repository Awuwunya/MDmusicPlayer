﻿namespace smps2asm {
	internal class Comment {
		public string v { get; }

		public Comment(string v) {
			this.v = v;
		}
	}
}