﻿namespace smps2asm {
	internal class Stop {
		public Stop() {
		}
	}
}