﻿namespace smps2asm {
	internal class ChangeLable {
		public string lable { get; }

		public ChangeLable(string l) {
			lable = l;
		}
	}
}